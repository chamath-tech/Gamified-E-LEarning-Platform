# SDGP-Project-Repository

A fullstack web development project:
E-learning platform where learners can self-learn Web development and update their skills,
Earn certifiacations
And create technical blogs and show case their knowledge
A gameroom is being developed (On progress) where instructers also can join nd create their quiz game and the Students can join and play the game and be ranked


_Follow the steps_:

make sure node is installed

run the frontend: <br/>
cd mindforge-project <br/>
npm install <br/>
npm run dev <br/>


The BackEnd:
The backend will not run if the dependencies are not properly installed and if the database is not connected (Atlas) <br/>
cd Backend <br/>
npm i  Express mongoose dotenv cors bcrypt jsonwebtoken cookie-parser multer<br/>
npm run start-dev<br/>
npm i path

To run the machine learning:<br/>
pip install scikit-learn <br/>
pip install streamlit <br/>
pip install neattext

// Finally run After every dependency is intalled correctly <br/>
streamlit run app.py 





