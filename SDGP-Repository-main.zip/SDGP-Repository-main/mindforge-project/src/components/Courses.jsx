
import "./CSS/Courses.css";

const Courses = () => {

  return (
    <div>
        <iframe
          title="Course Recommendation"
          src="http://localhost:8501"
          width="100%"
          height="1000"
          frameBorder="0"
          scrolling="no"
          style={{ border: "none" }}
        ></iframe>
    </div>
  );
};

export default Courses;
