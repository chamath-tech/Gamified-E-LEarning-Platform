import React from "react";

const RecommendationPage = () => {
  return (
    <div className="recommendation-page">
      <h2>Recommendation</h2>
      {/* Your recommendation content goes here */}
    </div>
  );
};

export default RecommendationPage;
